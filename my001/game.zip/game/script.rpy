# 遊戲腳本位於此檔案。

# 宣告該遊戲使用的角色。 color 參數
# 為角色的名稱著色。

# define e = Character("艾琳")
define c1g = Character("曉雯")
define p = Character("我", color="#5c3d2e")

# 初始化每個章節主角對大叔的好感度為 0
default c1_uncle_love = 0
default c1_end_select = 0

default c2_uncle_love = 0

# 建立一個相簿
init python:
    # 建立一個相簿物件
    g = Gallery()

    # 第一張照片：
    g.button("photo101") # 這是按鈕標籤
    g.unlock_image("c1_0030") # 對應的圖片檔名
    
    # 第二張照片：
    g.button("photo102")
    g.unlock_image("c1_0060")
    
    g.button("photo103")
    g.unlock_image("c1_0070")
    
    g.button("photo104")
    g.unlock_image("c1_0080")

    g.button("photo105")
    g.unlock_image("c1_0090")

    g.button("photo106")
    g.unlock_image("c1_0100")

    g.button("photo107")
    g.unlock_image("c1_0110")

    g.button("photo108")
    g.unlock_image("c1_0120")

    # 你可以設定「未解鎖」時顯示的預設圖
    g.locked_button = "gui/button/gallery_locked.png"


screen gallery_screen():
    tag menu # 確保這是一個選單介面
    add "gui/main_menu_bg.png" # 背景圖

    # 使用 vpgrid，設定列數 (cols)，不限制行數
    vpgrid:
        cols 2          # 固定的列數
        spacing 20
        align (0.5, 0.5)
        draggable True  # 支援滑鼠拖動
        mousewheel True # 支援滾輪

    
        # 第一張照片縮圖
        add g.make_button("photo101", "thumb_101.png", xsize=400, ysize=225)
        add g.make_button("photo102", "thumb_102.png", xsize=400, ysize=225)
        add g.make_button("photo103", "thumb_103.png", xsize=400, ysize=225)
        add g.make_button("photo104", "thumb_104.png", xsize=400, ysize=225)
        add g.make_button("photo105", "thumb_105.png", xsize=400, ysize=225)
        add g.make_button("photo106", "thumb_106.png", xsize=400, ysize=225)
        add g.make_button("photo107", "thumb_107.png", xsize=400, ysize=225)
        add g.make_button("photo108", "thumb_108.png", xsize=400, ysize=225)

    # 返回按鈕
    textbutton "返回主選單" action Return() align (0.1, 0.9)

# 遊戲從這裡開始。

label start:

    # 顯示背景。 預設情況下，它使用佔位符，但您可以
    # 將檔案（名為 "bg room.png" 或 "bg room.jpg"）新增至
    # images 目錄來顯示它。

    scene bg room
    # 顯示遊戲標題 (可以用置中的文字，或是直接畫在背景圖上)
    "歡迎來到《大叔的私密相簿》"

    # 3. 製作選擇選單
    menu:
        "請選擇要進行的章節："

        "故事：二十年後的重逢":
            jump chapter_1

        "故事：(構想中...)":
            jump chapter_2

        "本遊戲相簿":
            jump check_album

        "《大叔的私密相簿》":
            jump myphotosbook

        "關於本遊戲和作者":
            jump gameinfo


        "結束遊戲":
            return


    # 這顯示了一個角色精靈。 使用了佔位符，但您可以
    # 透過將名為 "eileen happy.png" 的檔案
    # 新增至 images 目錄來取代它。

    # show eileen happy

    # 這些顯示對話行。

    # e "您已經建立了一個新的 Ren'Py 遊戲。"

    # e "一旦您為其新增一段故事, 圖片和音樂, 您就可以將它發佈給全世界！"

    # 遊戲結束。

    # return

    label chapter_1:
    scene c1_0010

    play music "audio/houkagonoyuzora.ogg" fadein 2.0 fadeout 2.0

    

    "那天午後，台北的天空灰得像一張舊相紙，雨絲細細地斜織著..."
    "雨落在中山北路兩旁的行道樹上，發出輕微的沙沙聲。"
    "撐著那把用了五年的黑傘，慢慢走進「舊時光」咖啡廳。"
    p "內心獨白: 店名取得真老派，像在跟我這種五十出頭的老傢伙打招呼。"

    play sound "audio/door.ogg"

    "推門瞬間，風鈴輕響，混著烘豆的焦香和雨後的潮濕泥土味撲面而來。"
    "我習慣性地往角落那張靠窗的雙人桌走去，卻在半途僵住。"
    scene c1_0020 with fade   # 畫面淡入淡出切換
    p "等等~ 眼熟~ 她是..."
    scene c1_0030 with fade   # 畫面淡入淡出切換
    c1g "啊! 雲秋，是你嗎?"
    p "曉雯，好久不見~ 沒想到會遇見你!"
    scene c1_0040 with fade   # 畫面淡入淡出切換
    show c1g_fhn # 顯示立繪
    c1g "天啊! 好久不見...有二十年了吧!"
    hide c1g_fhn 
    show c1g_fhl
    p "真的沒想到，二十年後..."
    
    label choice_time:
    p "你依然..."

    menu:
        "那麼年輕漂亮呀！":
            $ c1_uncle_love += 5  # 加 5 分
            c1g "呵，你是轉性了嗎? 會稱讚人啦!"
            p "這些年! 世故了些!"
            c1g "一起聊個天吧!"

        "感覺一點都沒變！":
            $ c1_uncle_love += 5  # 加 5 分
            c1g "呵，你跟以前也差不多呀!"
            p "還過得去啦!"
            c1g "一起聊一下吧!"


        "呃...還是...我記憶中美好的樣子!":
            $ c1_uncle_love += 10   # 加 10 分
            c1g "那你有想我嗎?"
            p "蛤!"
            c1g "逗你的啦，幹嘛那麼緊張..."

    c1g "一起坐吧!"
    

    scene c1_0050 with fade   # 畫面淡入淡出切換
    show c1g_fhsh

    "二十年前，我們同一個小部門，她負責企劃，我寫程式。\n那時候她剛入社會，而我已是程式老手..."
    "有時候，總難免會加班~ 我總是趕她回家，但她呢...\n如果沒事，總會想辦法在辦公室陪我...哈哈，雖然根本幫不上忙。"
    "若忙得晚了，她還會買兩杯咖啡，我們就把辦公室當成咖啡廳，\n小聊一下天，振作我的精神...那一切，真值得懷念。"

    hide c1g_fhsh
    show c1g_fhst1

    c1g "仔細想想過去，那真是一個美好的過往呀!\n雖然，那時候...窮得叮噹響，哈哈!"
    c1g "有時候加班，你送我回家時，你還會請我吃晚餐、吃牛肉麵，記得嗎?"

    p "我記得...\n等等~那時候，你該不會是為了省錢，才硬要陪我加班吧! 哈哈哈!"
    c1g "亂講，哪有，我是陪你~ 陪你~"

    p "對了! 你後來...好像嫁入豪門? 所以離職了?"

    hide c1g_fhst1
    show c1g_fhst2 

    "她神態有點變化，避開了視線。"

    p "我說:"

    menu:
        "怎麼? 性生活不協調喔?":
            $ c1_uncle_love += 5  # 加 5 分
            c1g "哇! 你真的變了!"
            p "老公外遇?"
            c1g "誇張!"

        "孩子生幾個啦?":
            $ c1_uncle_love += 5  # 加 5 分
            c1g "沒有孩子啦!"
            p "老公...生理上有問題?"
            c1g "喂，換話題! 換話題!"


        "人與人之間，或許相愛容易相處難! 放寬心，一切會好的。":
            $ c1_uncle_love += 10   # 加 10 分
            c1g "嗯! 是有些相處上的問題!"
            p "要找第三者幫忙嗎? 參加婚姻諮商之類的。"
            c1g "謝謝你的建議!"

    
    hide c1g_fhst2
    show c1g_fhst3 with fade

    c1g "其實，我是離婚了!"
    hide c1g_fhst3


label ending_check:
    if c1_uncle_love <= 10:
        jump ending_10
    else:
        jump c1_story_020


label c1_story_020:
    show c1g_fhst2
    "啊! 我不經意的露出驚訝的表情!"
    c1g "我現在搬回台北，住在老家...哈哈哈，算 \"啃老族\" 嗎?"
    "我一時不知該說什麼~"
    "這時候~ 服務生剛好端我的咖啡給我..."
    c1g "還是兩顆，對吧？"
    "她習慣性地把方糖罐推到我面前!\n我點頭，喉頭有些發緊!"
    p "妳還記得。"
    c1g "當然記得。"
    hide c1g_fhst2
    show c1g_fhs
    "她低頭攪咖啡，泡沫在杯緣打轉，像一圈小小的漩渦。"
    c1g "那時候我總覺得，雲秋哥是世界上最溫柔的笨蛋。\n明明很喜歡我，卻連句告白都不敢說。"
    "我差點被咖啡嗆到，咳了兩聲，臉燙得像被誰拿熱鐵燙過"
    
    p "我說:"

    menu:
        "有嗎? 我想不起來了!":
            $ c1_uncle_love += 5  # 加 5 分
            c1g "沒有嗎? 那是我誤會了!"
            p "誤會! 誤會!"
            c1g "呵呵~"

        "我那時候，其實有女朋友!":
            $ c1_uncle_love += 5  # 加 5 分
            c1g "當時無緣吧!"
            p "嗯~ 無緣!"
            c1g "呵呵~"


        "你怎麼知道我喜歡妳?":
            $ c1_uncle_love += 10   # 加 10 分
            c1g "因為你每次看我的眼神..."
            c1g "都像在把全世界最貴重的東西藏起來，怕被人搶走。"
            p "有那麼明顯?"
            c1g "呵呵~"

    hide c1g_fhs
    show c1g_fhsh

    "我忽然覺得，這一刻的我們...\n像被時間偷偷藏進了一個只有我們倆的時空中。"
    "外面的世界繼續下雨、繼續喧鬧，而這裡只有呼吸與心跳。"
 
    p "曉雯:"

    menu:
        "我有開車，我們去...motel":
            $ c1_uncle_love += 5  # 加 5 分
            c1g "摸~你的頭啦~ 我是這種人嗎?"
            p "誤會! 誤會!"
            c1g "誤會大了你!"

        "其實，我一直也沒忘記你，雖然我結婚了!":
            $ c1_uncle_love += 5  # 加 5 分
            c1g "無緣! 無緣了!"
            p "嗯~ 你能當小三嗎?"
            c1g "三~ 搧你個頭~ 不幹!"


        "如果當年我說了，妳會不會……":
            $ c1_uncle_love += 10   # 加 10 分
            c1g "別問如果。問現在。"
            p "我五十四歲、未婚、沒有女朋友...當然也沒孩子...＠＊＃％＆"
            c1g "嘻嘻~ 哥~ 你在緊張啥?"
            p "我....我...."
            
label ending_check2:
    if c1_uncle_love < 40:
        jump ending_20
    else:
        jump c1_story_030
    
label c1_story_030:    
    
    hide c1g_fhsh
    show c1g_fhne

    "她把手伸過來，掌心朝上，放在桌中央，像一朵靜靜等待露水的花朵。"
    "我猶豫了三秒..."
    "然後把我的左手覆上去，她的手溫熱，\n帶著一點咖啡的餘溫，指尖微微顫抖，像冬夜裡最後一口熱可可的蒸氣。"
    "我們就這樣靜靜握著，沒說話。窗外的雨絲變密了，\n玻璃上凝出一層薄霧，把外面的街景糊成一幅印象派畫作。"
    
    hide c1g_fhne
    show c1g_fhne1

    "過了好一會兒..."
    c1g "今晚……可以陪我走走嗎？"
    
    hide c1g_fhne1
    show c1g_fhne2

    "我點頭，喉嚨發澀..."
    p "「好。」"

    scene c1_0060 with fade   # 畫面淡入淡出切換

    "我起身，向她伸出了手!"
    "結帳，拉著她一起走出了店外!"

    scene c1_0070 with fade   # 畫面淡入淡出切換

    "雨，還微微下著..."

    scene c1_0080 with fade   # 畫面淡入淡出切換

    "我趕緊把她摟入傘下，她害羞的微微低頭..."

    p "這時候..."
    menu:
        "親下去囉~ 還猶豫!":
            $ c1_end_select = 1
            

        "要去哪裡走走?":
            c1g "嗯，你想去哪裡?"
            p "看夜景如何?"
            c1g "好呀!"
            $ c1_end_select = 2
            

        "走~ 續攤! 吃晚餐!":
            c1g "喔! 想吃啥!"
            p "吃你..."
            c1g "什麼?"
            p "吃你...老家附近的那間牛肉麵，還開著嗎?"
            c1g "哈! 還開著，走!"
            $ c1_end_select = 3
            
label ending_check3:
    if c1_end_select == 1:
        jump ending_110
    elif c1_end_select == 2:
        jump ending_120
    else:
        jump ending_130

label ending_110:
    scene c1_0090 with fade
    c1g "嗯~"
    p "你的唇真甜!"
    c1g "討厭!"
    jump c1_story_040


label ending_120:
    scene c1_0100 with fade
    c1g "雨停了以後，風景真美!"
    p "你也很美~"
    c1g "討厭!"
    jump c1_story_040


label ending_130:
    scene c1_0110 with fade
    c1g "嗯，還是熟悉的味道，真好!"
    p "重點是...有你一起吃，更美味了。"

    jump c1_story_040

label c1_story_040:

    scene c1_0120 with fade
    p "老樣子~ 我送你回家吧!"
    c1g "有你陪著真好~"

    "其實，依照 大叔幻想 的慣例，後面，是還有戲的!"
    "但是，因為此遊戲直接在網路發布，有些內容(NSFW)，是無法公開的。"
    "所以，欲知後事如何，請移駕...{a=https://vocus.cc/article/69b8ed88fd897800017491a1}→ 二十年後的重逢(限) ←{/a} "
    "本篇就在這裡結束囉，謝謝您的遊玩。"


    jump ending_9999

label ending_20:
    scene c1_0050 
    show c1g_fha with fade
    c1g "對了，我還有事，我先走了..."
    "結局: 無緣的結局!"

    jump ending_9999


label ending_10:
    scene c1_0050 
    show c1g_fha with fade
    c1g "我還有事，我先走了..."
    "結局: 話不投機半句多。"

    jump ending_9999

label ending_9999:

    stop music fadeout 1.0  # 在 1 秒內慢慢淡出停止
    # 章節結束後回到選單或是結束
    jump start 

label chapter_2:
    scene bg bathroom
    p "哎呀，還沒想到要寫啥呢!\n(第二個故事內容...從缺)"
    
    jump start

label myphotosbook:
    p "我想把我部落格中的文章連結至此\n等有時間，再想想怎麼做。"
    p "抱歉! 目前尚無內容。"
    jump start

label gameinfo:
    scene bg gameinfo
    play music "audio/morinonakanotorii.ogg" fadein 2.0 fadeout 2.0

    p "我是一個五十多歲的大叔..."
    
    show img mysite at center with dissolve # 圖片角色慢慢浮現
    p "原本，只是工作閒暇之餘，玩玩AI..."
    p "玩著玩著，喜歡上 AI 生圖，於是動念，來寫個 {a=https://vocus.cc/salon/aicg18}→ 專門用 AI 生圖的部落格 ←{/a} 玩玩!"
    hide img mysite with dissolve # 圖片角色會慢慢變透明直到消失
    p "現在，我在想，寫個視覺小說 來推廣 {a=https://vocus.cc/salon/aicg18}→ 部落格 ←{/a} 好像也不錯，"
    p "於是就有這個遊戲囉! 希望您會喜歡這個遊戲。"
    p "醬捏~"
    
    stop music fadeout 1.0  # 在 1 秒內慢慢淡出停止

    jump start

label check_album:
    call screen gallery_screen
    jump start